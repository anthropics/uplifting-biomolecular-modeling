Code of Conduct
===============

Facebook has adopted a Code of Conduct that we expect project participants to adhere to. Please `read the full text`__ so that you can understand what actions will and will not be tolerated.

__ https://code.facebook.com/codeofconduct
