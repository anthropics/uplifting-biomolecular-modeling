"""Generation workflow adapters."""
