"""Inverse folding model handlers."""
