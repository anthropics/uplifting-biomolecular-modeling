"""Structure folding model handlers."""
