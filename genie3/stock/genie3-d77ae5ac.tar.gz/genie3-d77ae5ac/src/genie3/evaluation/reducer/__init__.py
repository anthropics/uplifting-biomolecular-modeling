"""Evaluation reducers."""
