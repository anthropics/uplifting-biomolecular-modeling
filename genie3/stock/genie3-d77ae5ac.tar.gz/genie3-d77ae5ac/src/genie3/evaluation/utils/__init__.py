"""Evaluation utility functions."""
